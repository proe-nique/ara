from django.db import models
from django.utils.text import slugify
#from django.utils import timezone as time
# Create your models here...

    
class Construct(models.Model):
    """Model definition for Construct."""

    # TODO: Define fields here
    name = models.CharField(default='', max_length=50)
    image = models.ImageField(default='construction/test.svg', upload_to='construction')
    description = models.TextField()
    slug = models.SlugField(unique=True, blank=True)
    
    class Meta:
        """Meta definition for Construct."""

        verbose_name = 'Construct'
        verbose_name_plural = 'Constructs'

    def __str__(self):
        """Unicode representation of Construct."""
        return self.name
    
    def save(self):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save()

    def get_absolute_url(self):
        from django.urls import reverse
        return reverse('construction:detail', kwargs={'slug': self.slug})
    
class Service(models.Model):
    """Model definition for Service."""

    # TODO: Define fields here
    category = models.ForeignKey('Construct', on_delete=models.CASCADE)
    name = models.CharField(default='', max_length=50)
    slug = models.SlugField(unique=True, blank=True)

    class Meta:
        """Meta definition for Service."""

        verbose_name = 'Service'
        verbose_name_plural = 'Services'

    def __str__(self):
        """Unicode representation of Service."""
        return self.name

    def save(self):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save()
    
