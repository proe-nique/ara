from django.db import models
from django.utils.text import slugify
from django.utils import timezone as time
# Create your models here...

    
class Tracker(models.Model):
    """Model definition for Tracker."""

    # TODO: Define fields here
    name = models.CharField(default='', max_length=50)
    image = models.ImageField(default='tracking/test.svg', upload_to='tracking')
    description = models.TextField()
    background = models.TextField()
    overview = models.TextField()
    disadvantage = models.TextField()
    slug = models.SlugField(unique=True, blank=True)
    
    class Meta:
        """Meta definition for Tracker."""

        verbose_name = 'Tracker'
        verbose_name_plural = 'Trackers'

    def __str__(self):
        """Unicode representation of Tracker."""
        return self.name
    
    def save(self):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save()

    def get_absolute_url(self):
        from django.urls import reverse
        return reverse('tracking:detail', kwargs={'slug': self.slug})
    

    
# PRODUCT MODEL
class Product(models.Model):
    """Model definition for Product."""

    # TODO: Define fields here
    category = models.ForeignKey('Tracker', on_delete=models.CASCADE)
    image = models.ImageField(default='products/default.png', upload_to='products/')
    name = models.CharField(default='', max_length=50)
    overview = models.TextField()
    slug = models.SlugField(unique=True, blank=True)

    class Meta:
        """Meta definition for Product."""

        verbose_name = 'Product'
        verbose_name_plural = 'Products'

    def __str__(self):
        """Unicode representation of Product."""
        return self.name

    def get_absolute_url(self):
        from django.urls import reverse
        return reverse('tracking:product_detail', kwargs={'slug': self.slug})    

    def save(self):
        if not self.slug:
            self.slug = slugify(self.name)
        return super().save()    
    
class Component(models.Model):
    """Model definition for Component."""

    # TODO: Define fields here
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    name = models.CharField(default='', max_length=50)
    
    class Meta:
        """Meta definition for Component."""

        verbose_name = 'Component'
        verbose_name_plural = 'Components'

    def __str__(self):
        """Unicode representation of Component."""
        return self.name


class Advantage(models.Model):
    """Model definition for Advantage."""

    # TODO: Define fields here
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    name = models.CharField(default='', max_length=50)
    
    class Meta:
        """Meta definition for Advantage."""

        verbose_name = 'Advantage'
        verbose_name_plural = 'Advantages'

    def __str__(self):
        """Unicode representation of Advantage."""
        return self.name


   