from django.contrib import admin
from .models import Construct, Service
# Register your models here.

admin.site.register(Construct)
admin.site.register(Service)