from django.shortcuts import render, get_object_or_404, get_list_or_404
from .models import Tracker, Product, Advantage, Component

# Create your views here.

def track_list(request):
    template_name = 'tracking.html'
    trackers = Tracker.objects.all()
    
    context = {
        'page_title':'tracking',
        'trackers':trackers,
    }
    return render(request, template_name, context)

def track_detail(request, slug):
    template_name = 'track_detail.html'
    track = Tracker.objects.get(slug=slug)
    products = Product.objects.filter(category=track)
    
    context = {
        'page_title': slug,
        'track': track,
        'products': products,
    }
    
    return render(request, template_name, context)

def product_detail(request, slug):
    template_name = 'prod_detail.html'
    product = Product.objects.get(slug=slug)
    advs = Advantage.objects.filter(product=product)
    comps = Component.objects.filter(product=product)
    
    context = {
        'page_title':slug,
        'product':product,
        'advs':advs,
        'comps':comps,
    }
    return render(request, template_name, context)