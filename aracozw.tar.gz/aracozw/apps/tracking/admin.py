from django.contrib import admin
from .models import Tracker, Product, Advantage, Component
# Register your models here.

admin.site.register(Tracker)
admin.site.register(Product)
admin.site.register(Advantage)
admin.site.register(Component)