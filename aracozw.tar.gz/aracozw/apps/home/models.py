from django.db import models
from django.utils.text import slugify
from django.utils import timezone as time
# Create your models here...

class GalleryImage(models.Model):
    service = models.ForeignKey('construction.Service', related_name='service_image', on_delete=models.CASCADE)
    img = models.ImageField(default='', upload_to='gallery/')
    name = models.CharField(default='', max_length=50)
    slug = models.SlugField(unique=True, blank=True)
    
    def __str__(self):
        return self.name

    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'Gallery Image'
        verbose_name_plural = 'Gallery Images'
        
    def save(self):
        if not self.slug:
            self.slug = slugify(self.service.name +'-'+ self.name)
        return super().save()    
    
class Review(models.Model):
    """Model definition for Review."""

    # TODO: Define fields here
    image = models.ImageField(default='/testimonials/team.png', upload_to='testimonials/')
    name = models.CharField(default='', max_length=50)
    job_description = models.CharField(default='', max_length=50)
    review = models.TextField()
    published_date = models.DateTimeField(default=time.now)
    slug = models.SlugField(unique=True, blank=True)

    class Meta:
        """Meta definition for Review."""

        verbose_name = 'Review'
        verbose_name_plural = 'Reviews'

    def __str__(self):
        """Unicode representation of Review."""
        return self.name

    def get_absolute_url(self):
        from django.urls import reverse
        return reverse('home:service_detail', kwargs={'slug': self.slug})

    def save(self):
        if not self.slug:
            self.slug = slugify(self.name + self.job_description)
        return super().save()
