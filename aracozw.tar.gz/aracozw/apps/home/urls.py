
from . import views
from django.urls import path


app_name = 'home'


urlpatterns = [
    path('', views.home_view, name='home'),
    path('gallery/', views.gallery_view, name='gallery'),
    path('review/', views.ReviewCreateView.as_view(), name='review'),
    path('success/', views.successView, name="success"),
]
