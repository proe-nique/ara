
from . import views
from django.urls import path


app_name = 'tracking'


urlpatterns = [
    path('track_list/', views.track_list, name='list'),
    path('track_detail/<slug>/', views.track_detail, name='detail'),
    path('product_detail/<slug>/', views.product_detail, name='product_detail'),
]