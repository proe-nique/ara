
from . import views
from django.urls import path


app_name = 'construction'


urlpatterns = [
    path('const_list/', views.const_list, name='list'),
    path('const_detail/<slug>/', views.const_detail, name='detail'),
]
