from django.shortcuts import render, get_list_or_404, get_object_or_404
from .models import Construct, Service
from apps.home.models import GalleryImage


# Create your views here.

def const_list(request):
    template_name = 'construction.html'
    consts = Construct.objects.all()
    
    
    context = {
        'page_title':'construction',
        'consts':consts,
    }

    return render(request, template_name, context)



def const_detail(request, slug):
    template_name = 'const_detail.html'
    const = Construct.objects.filter(slug=slug).all()
    svs = Service.objects.filter(category=const).all()
    service_images = GalleryImage.objects.all()
    
    
    
    context = {
        'page_title':slug,
        'const':const,
        'services':svs,
        'service_images':service_images,
        
    }

    return render(request, template_name, context)
