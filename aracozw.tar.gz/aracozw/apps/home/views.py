from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.urls import reverse
from django.shortcuts import render , redirect, get_list_or_404
from apps.construction.models import Construct
from apps.tracking.models import Tracker
from .models import GalleryImage
from apps.users.models import Profile
from .models import Review
from .forms import ReviewForm, ContactForm
from django.views.generic import CreateView

# Create your views here.




def home_view(request):
    if request.method == "GET":
        template_name = 'home.html'
        tracks = Tracker.objects.all()
        consts = Construct.objects.all()
        gallery = GalleryImage.objects.all()[:5]
        members = Profile.objects.all()
        reviews = Review.objects.all().order_by('id')[:3]
        form = ContactForm()
    else:
        form = ContactForm(request.POST)
        if form.is_valid():
            subject = form.cleaned_data["subject"]
            from_email = form.cleaned_data["from_email"]
            message = form.cleaned_data['message']
            try:
                send_mail(subject, message, from_email, ["info@ara.co.zw"])
            except BadHeaderError:
                return HttpResponse("Invalid header found.")
            return redirect("home:success")
    context = {
        'page_title':'home',
        'tracks':tracks,
        'consts':consts,
        'gallery':gallery,
        'members':members,
        'reviews':reviews,
        'form': form,
    }
    return render(request, template_name, context)

def gallery_view(request):
    template_name = 'full-gallery.html'
    gallery = GalleryImage.objects.all()
    context={
        'gallery':gallery,
    }
    return render(request, template_name, context)


def successView(request):
    return HttpResponse("Success! Thank you for your message.")

class ReviewCreateView(CreateView):
    model = Review
    template_name = "review.html"
    form_class = ReviewForm
    success_url = 'home:home'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'review us'
        return context

    def form_valid(self, form):
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('home:home')
    
